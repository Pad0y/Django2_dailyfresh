# encoding: utf-8

import warnings
warnings.simplefilter('ignore', Warning)
